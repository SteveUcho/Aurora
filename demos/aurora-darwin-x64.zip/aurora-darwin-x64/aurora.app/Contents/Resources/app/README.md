# Aurora
* Hey there! This is Aurora
* Its just a placeholder
* Hoping to make this an educational machine learning visualizer

### What I mean
You'll be able to create, run, and debug your models using Aurora
Most of all, little to no code would be required!
* Use basic drag and drop features to add layers, etc...
* Suggests best models for specific purposes
* and (hopefully) much more!

### How to get started!
> **NOTE**: this is just testing stuff, so don't expect anything *too* crazy rn...
* Clone the repository
* Download [Node.js](https://nodejs.org/en/)
* `cd` to Aurora
* Run `npm start`
